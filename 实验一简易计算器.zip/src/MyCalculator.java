import javax.swing.*;
import java.awt.*;

/*用于计算机的设置*/
public class MyCalculator extends JFrame {
    String res="";//计算器最终的文本结果
    boolean nodCan=true;

    public MyCalculator(){
    }

    private JTextField text=new JTextField("");//文本框
    private JButton buttonAC =new JButton("AC");
    private JButton buttonZKH =new JButton("(");
    private JButton buttonYKH =new JButton(")");
    private JButton buttonDelete =new JButton("Del");

    private JButton button7 =new JButton("7");
    private JButton button8 =new JButton("8");
    private JButton button9 =new JButton("9");
    private JButton buttonAdd =new JButton("+");

    private JButton button4 =new JButton("4");
    private JButton button5 =new JButton("5");
    private JButton button6 =new JButton("6");
    private JButton buttonMinus =new JButton("-");

    private JButton button1 =new JButton("1");
    private JButton button2 =new JButton("2");
    private JButton button3 =new JButton("3");
    private JButton buttonMult =new JButton("*");

    private JButton button0 =new JButton("0");
    private JButton buttonNod =new JButton(".");
    private JButton buttonDivid =new JButton("/");
    private JButton buttonResult =new JButton("=");


    public MyCalculator(String title){
        super(title);
        Container container=getContentPane();//创建内容面板
        container.add(text, BorderLayout.NORTH);//添加文本框
        text.setPreferredSize(new Dimension(0,50));//设置文本框高度
        text.setHorizontalAlignment(JTextField.RIGHT);//文本框内文本向右对齐
        text.setFont(new Font("微软雅黑",0,28));
        text.setForeground(Color.BLUE);
//       container.setLayout(null);


        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5,5,2,2));
        createButton(panel);
        addButtonAct();


        container.add(panel,BorderLayout.CENTER);
    }

    //添加按钮
    public void createButton(JPanel panel){
        panel.add(buttonAC);
        panel.add(buttonZKH);
        panel.add(buttonYKH);
        panel.add(buttonDelete);

        panel.add(button7);
        panel.add(button8);
        panel.add(button9);
        panel.add(buttonAdd);

        panel.add(button4);
        panel.add(button5);
        panel.add(button6);
        panel.add(buttonMinus);

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(buttonMult);

        panel.add(button0);
        panel.add(buttonNod);
        panel.add(buttonDivid);
        panel.add(buttonResult);
    }

    //设置基本按钮事件
    public void buttonAct(JButton jb){
        jb.addActionListener(x->{
            if(text.getText().equals("0"))text.setText(jb.getText());
            else
                text.setText(text.getText()+jb.getText());
        });
    }

    //给所有按钮附加事件
    public void addButtonAct() {
        buttonAct(button1);
        buttonAct(button2);
        buttonAct(button3);
        buttonAct(button4);
        buttonAct(button5);
        buttonAct(button6);
        buttonAct(button7);
        buttonAct(button8);
        buttonAct(button9);

        buttonAct(buttonYKH);

        //加
        buttonAdd.addActionListener(x->{
            if(!isShuZi()) return;
            else  {text.setText(text.getText()+"+");nodCan=true;}
        });

        //减
        buttonMinus.addActionListener(x->{
            if(!isShuZi()) return;
            else  {text.setText(text.getText()+"-");nodCan=true;}
        });

        //乘
        buttonMult.addActionListener(x->{
            if(text.getText().length()==0||!isShuZi()) return;
            else  {text.setText(text.getText()+"*");nodCan=true;}
        });

        //除
        buttonDivid.addActionListener(x->{
            if(text.getText().length()==0||!isShuZi()) return;
            else  {text.setText(text.getText()+"/");nodCan=true;}
        });

        //左括号
        buttonZKH.addActionListener(x->{
            if(text.getText().length()!=0&&isShuZi()) return;
            else  {text.setText(text.getText()+"(");nodCan=true;}
        });

        //小数点
        buttonNod.addActionListener(x->{
            if(text.getText().length()==0||!isShuZi()||!nodCan) return;
            else  {text.setText(text.getText()+".");nodCan=false;}
        });

        //0
        button0.addActionListener(x->
        {
            if(text.getText().equals("0"))
                text.setText("0");
            else
                text.setText(text.getText()+"0");
        });

        //删除
        buttonDelete.addActionListener(x->
                {
                    if(text.getText().length()==0) return;
                    else if(text.getText().length()==1) text.setText("");
                    else text.setText(text.getText().substring(0,text.getText().length()-1));
                }
        );

        //清空
        buttonAC.addActionListener(x-> text.setText(""));

        //等于
        buttonResult.addActionListener(x->{
            double res=TheBest.result(text.getText());
            if(res-Math.floor(res)==0)text.setText(""+(int)res);
            else
                text.setText(""+res);
        });
    }

    public boolean isShuZi(){
        if(text.getText().length()==0) return false ;
        char c=text.getText().charAt(text.getText().length()-1);
        if(c=='+'||c=='-'||c=='*'||c=='/'||c=='.'||c=='('||c==')')return false;
        else return true;
    }

}
