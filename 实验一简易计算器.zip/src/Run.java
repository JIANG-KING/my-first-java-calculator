import javax.swing.*;
import java.awt.*;

/*用于计算器的调用*/
public class Run {
    public static void main(String[] args) {
        JFrame myCalculator = new MyCalculator("wdnmd闸总计算器");
        myCalculator.setVisible(true);
        myCalculator.setBounds(300,400,300,400);
        myCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}