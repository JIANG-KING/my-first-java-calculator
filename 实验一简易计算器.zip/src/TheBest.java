

import java.util.ArrayList;
import java.util.LinkedList;

/*
 * @用于计算器文本框显示出计算公式后的计算
 * @用双栈实现的后缀表达式求值
 * */
public class TheBest {

    //计算文本公式的值
    public static Double result(String s){
        return compute(mid2back(s));
    }

    //转化后缀表达式
    public static ArrayList mid2back(String s) {
        if(s.charAt(0)=='-'||s.charAt(0)=='+')s="0"+s;
        ArrayList res = new ArrayList();//结果
        LinkedList<Character> st = new LinkedList<>();//符号栈
        int size = s.length();
        for (int i = 0; i < size; i++) {
            if (s.charAt(i) != '(' && s.charAt(i) != ')' && s.charAt(i) != '+' && s.charAt(i) != '*' && s.charAt(i) != '-' && s.charAt(i) != '/') {
                int resx=i+1;//记录x
                boolean isqian=true;
                String s1="";//小数点前
                double a1=0;//小数点前
                s1+=s.charAt(i);//将刚刚的数字放入小数点前
                String s2="";//小数点后
                double a2=0;//小数点后
                for (int x=i+1;x<size;x++)//已经是数字的前提下查看后面是否有数字
                {
                    //如果为数字或小数点则判断
                    if(s.charAt(x) != '(' && s.charAt(x) != ')' && s.charAt(x) != '+' && s.charAt(x) != '*' && s.charAt(x) != '-' && s.charAt(x) != '/'){
                        //数字
                        if(s.charAt(x)!='.'){
                            if(isqian)s1+=s.charAt(x);//如果为小数点前的数则加入s1
                            else s2+=s.charAt(x);//否则加入s2
                            resx=x;
                            continue;
                        }
                        //小数点
                        else {
                            isqian=false;
                            resx=x;
                            continue;
                        }
                    }
                    //如果为括号或操作符则退出
                    else{
                        resx=x;
                        break;
                    }
                }

                double pow1=1;//小数点前
                double pow2=0.1;//小数点后
                //取出s1
                for (int i1=s1.length()-1;i1>=0;i1--){
                    a1+=(s1.charAt(i1)-'0')*pow1;
                    pow1*=10;
                }
                //取出s2
                for (int i2=0;i2<s2.length();i2++)
                {
                    a2+=(s2.charAt(i2)-'0')*pow2;
                    pow2*=0.1;
                }
                //s1s2加入res
                res.add(a1+a2);
                if(resx==size-1&&s.charAt(size-1)!=')')break;//如果最后表达式最后一位不是括号则直接退出
                i=resx-1;
                continue;
            }//数字直接放入算术表达式res
            if (s.charAt(i) == '(') {
                st.add(s.charAt(i));
                continue;
            }//'('左括号优先级最高 直接入栈
            if (s.charAt(i) == '+' || s.charAt(i) == '*' || s.charAt(i) == '-' || s.charAt(i) == '/')//或'*' '+' '-' '/'
            {
                if (st.isEmpty())
                    st.add(s.charAt(i));//栈空 算术符号入栈
                else//否则根据算术符号优先级出栈
                    while (true) {
                        char temp = st.getLast();//栈顶算术符号
                        if (priority(s.charAt(i), temp))//栈顶算术符号优先级高于当前算术符号
                        {
                            st.add(s.charAt(i));//入栈
                            break;//出循环
                        } else {
                            res.add(temp);//否则栈顶算术符号放入算术表达式
                            st.removeLast();//直到当前算术符号优先级小于栈顶算术符号
                            if (st.isEmpty())//如果栈空 那么当前算术符号入栈
                            {
                                st.add(s.charAt(i));
                                break;//出循环
                            }
                        }
                    }

            }
            if (s.charAt(i) == ')')//如果是右括号
            {
                while (st.getLast() != '(')//算术符号出栈 直到栈顶为左括号
                {
                    res.add(st.getLast());
                    st.removeLast();
                }
                st.removeLast();//'('出栈 且不放入算术表达式
            }
        }
        while (!st.isEmpty())//栈中剩余算术符号放入算术表达式
        {
            res.add(st.getLast());
            st.removeLast();
        }
        return res;//转换后的算术
    }

    //后缀表达式求值
    public static double compute(ArrayList str)//根据后缀算术表达式计算值
    {
        LinkedList<Double> st=new LinkedList<>();
        int size = str.size();
        for (int i = 0; i < size; i++)
        {
            if (!str.get(i).equals('+') &&!str.get(i).equals('*')&&!str.get(i).equals('-')&&!str.get(i).equals('/'))
                st.add((double)str.get(i));//数字入栈 注意char转int
            if (str.get(i).equals('+'))//执行加法
            {
                double a = st.getLast();
                st.removeLast();
                double b = st.getLast();//取栈顶两元素
                st.removeLast();
                st.push(a + b);//加法的和入栈
            }
            if (str.get(i).equals('*'))//执行乘法
            {
                double a = st.getLast();
                st.removeLast();
                double b = st.getLast();//取栈顶两元素
                st.removeLast();
                st.push(a*b);//乘法的积入栈
            }
            if (str.get(i).equals('/'))//执行除法
            {
                double a = st.getLast();
                st.removeLast();
                double b = st.getLast();//取栈顶两元素
                st.removeLast();
                st.push(b/a);//乘法的积入栈
            }
            if (str.get(i).equals('-'))//执行乘法
            {
                double a = st.getLast();
                st.removeLast();
                double b = st.getLast();//取栈顶两元素
                st.removeLast();
                st.push(b-a);//乘法的积入栈
            }
        }
        return st.getLast();//返回后缀表达式的计算结果
    }

    //优先级比较
    public static boolean priority(char a, char b) {
        //算术优先级a>b 返回true
        //加法
        if (a == '+' && b == '+')
            return false;
        if (a == '+' && b == '*')
            return false;
        if (a == '+' && b == '/')
            return false;
        if (a == '+' && b == '(')
            return true;
        if (a == '+' && b == '-')
            return false;
        //减法
        if (a == '-' && b == '+')
            return false;
        if (a == '-' && b == '-')
            return false;
        if (a == '-' && b == '*')
            return true;
        if (a == '-' && b == '/')
            return true;
        if (a == '-' && b == '(')
            return true;
        //乘法
        if (a == '*' && b == '+')
            return true;
        if (a == '*' && b == '-')
            return true;
        if (a == '*' && b == '*')
            return false;
        if (a == '*' && b == '/')
            return false;
        if (a == '*' && b == '(')
            return true;
        //除法
        if (a == '/' && b == '+')
            return true;
        if (a == '/' && b == '-')
            return true;
        if (a == '/' && b == '*')
            return false;
        if (a == '/' && b == '/')
            return false;
        if (a == '/' && b == '(')
            return true;
        return false;
    }
}
